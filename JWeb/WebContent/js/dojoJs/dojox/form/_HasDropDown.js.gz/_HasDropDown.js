/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["dojox.form._HasDropDown"]){dojo._hasResource["dojox.form._HasDropDown"]=true;dojo.deprecated("dojox.form._HasDropDown","Use dijit._HasDropDown instead","2.0");dojo.provide("dojox.form._HasDropDown");dojo.require("dijit._HasDropDown");dojo.setObject("dojox.form._HasDropDown",dijit._HasDropDown);}