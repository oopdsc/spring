/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["dojox.form._FormSelectWidget"]){dojo._hasResource["dojox.form._FormSelectWidget"]=true;dojo.deprecated("dojox.form._FormSelectWidget","Use dijit.form._FormSelectWidget instead","2.0");dojo.provide("dojox.form._FormSelectWidget");dojo.require("dijit.form._FormSelectWidget");dojo.setObject("dojox.form._FormSelectWidget",dijit.form._FormSelectWidget);}