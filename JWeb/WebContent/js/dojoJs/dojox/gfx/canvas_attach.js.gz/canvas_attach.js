/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


dojo.require("dojox.gfx.canvas");dojo.experimental("dojox.gfx.canvas_attach");dojox.gfx.attachNode=function $DAHW_(){return null;};