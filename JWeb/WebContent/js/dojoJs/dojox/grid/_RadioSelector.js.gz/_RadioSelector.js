/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["dojox.grid._RadioSelector"]){dojo._hasResource["dojox.grid._RadioSelector"]=true;dojo.provide("dojox.grid._RadioSelector");dojo.require("dojox.grid._Selector");}