/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["dojox.grid.enhanced.plugins.DnD"]){dojo._hasResource["dojox.grid.enhanced.plugins.DnD"]=true;dojo.provide("dojox.grid.enhanced.plugins.DnD");dojo.require("dojox.grid.enhanced.dnd._DndMovingManager");dojo.declare("dojox.grid.enhanced.plugins.DnD",dojox.grid.enhanced.dnd._DndMovingManager,{});}