/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


dojo.declare("dijit.tree.model",null,{destroy:function $DNE_(){},getRoot:function $DNF_(_1){},mayHaveChildren:function $DNG_(_2){},getChildren:function $DNH_(_3,_4){},isItem:function $DNI_(_5){},fetchItemByIdentity:function $DNJ_(_6){},getIdentity:function $DNK_(_7){},getLabel:function $DNL_(_8){},newItem:function $DNM_(_9,_a,_b){},pasteItem:function $DNN_(_c,_d,_e,_f){},onChange:function $DNO_(_10){},onChildrenChange:function $DNP_(_11,_12){}});